/*****************************
*@author tisha kanjilal
*
*@title  HW2 -SWE645 -Fall2017
*
*******************************/
package controller;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.faces.application.FacesMessage;
//import javax.annotation.ManagedBean;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;


@ManagedBean(name="surveyBean")
@SessionScoped
public class SurveyBean {
	
boolean flag=false;	
private Student student=new Student();
private StudentService studentService=new StudentService();
private WinningResult winningResult=new WinningResult();


SurveyBean getInstance(){
	return this;
}


/** getter and setter for List of students - survey info **/

public void setStudentList(ArrayList<Student> list)
{
	winningResult.setStudentList(list);
}
public ArrayList<Student> getStudentList()
{
 return winningResult.getStudentList();
}




/** getters and setters of WinningResult model properties **/

public void setmean(double mean)
{
	winningResult.setmean(mean);
}
public double getmean()
{
 return winningResult.getmean();
}


public void setstDev(double stDev)
{
	winningResult.setstDev(stDev);
}
public double getstDev()
{
 return winningResult.getstDev();
}

/**getters and setters of Student  model properties**/
public String getFname() {
	return this.student.getFname();
}

public void setFname(String fname) {
	this.student.setFname(fname);
}

public String getLname() {
	return this.student.getLname();
}

public void setLname(String lname) {
	this.student.setLname(lname);
}

public String getAddress() {
	return this.student.getAddress();
}

public void setAddress(String address) {
	this.student.setAddress(address);;
}

public String getCity() {
	return this.student.getCity();
}

public void setCity(String city) {
	this.student.setCity(city);;
}

public String getState() {
	return this.student.getState();
}

public void setState(String state) {
	this.student.setState(state);;
}

public String getZip() {
	return this.student.getZip();
}

public void setZip(String zip) {
	this.student.setZip(zip);;
}

public String getPhone() {
	return this.student.getPhone();
}

public void setPhone(String phone) {
	this.student.setPhone(phone);;
}

public String getEmail() {
	return this.student.getEmail();
}

public void setEmail(String email) {
	this.student.setEmail(email);;
}

public String getDate() {
	return this.student.getDate();
}

public void setDate(String date) {
	
	this.student.setDate(date);
}

public String[] getCheck() {
	
	return student.getCheck();
}

public void setCheck(String[] check) {
	this.student.setCheck(check);
}

public String getChkbx() {
	return student.getChkbx();
}

public void setChkbx(String chkbx) {
	student.setChkbx(chkbx);;
}

public String getRadio() {
	return student.getRadio();
}

public void setRadio(String radio) {
	
	System.out.println("Radio:"+radio);
	this.student.setRadio(radio);
	
}

public String getMenu() {
	return student.getMenu();
}

public void setMenu(String menu) {
	student.setMenu(menu);
}

public String getRaffle() {
	
	return this.student.getRaffle();
}

public void setRaffle(String raffle) {
	
	/** Validating Raffle before computing Mean and Standadrd Deviation **/
	
	double mean=0.0,stDev=0.0;
	if(validateRaffle(raffle)){
		// If true we set the Raffle
		student.setRaffle(raffle);
		mean=studentService.calculateMean(student.getRaffle());
		stDev=studentService.calculateStDev(student.getRaffle());
		setmean(mean);
		setstDev(stDev);
		
		
		
	}else{
		//else goto page and show error for raffle validation  
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("raffle",
				new FacesMessage("Please  enter atleast 10 valid numbers between 1 and 100"));
		
		
	}
		
	}

public String getComment() {
	return student.getComment();
}

public void setComment(String comment) {
	student.setComment(comment);;
}




public String showData(){
	String chkbx="";

	if(flag==false){
		return "index.xhtml";
	}
	
	/** Setting checkbox options as string **/
	for(String s:getCheck())
	{
		chkbx+=s;
		chkbx+=",";
	}
	setChkbx(chkbx);
	
	/** store the survey data **/
	
	studentService.storeData(this.getInstance());
	
	/** setting the list of all surveys taken till date **/
	final ArrayList<Student> studRow;
	studRow=studentService.fetchData();
	setStudentList(studRow);
	if(getmean()>90)
		return "winner";
	else 
		return "simple";

}



public boolean validateRaffle(String myraffle){
	System.out.println("Am going to validate the raffle");
	
	int min,max,token;
	
	//check if myraffle is null
	if(myraffle==null)
		return false;
	
	String[] tokens = myraffle.split(",");
	System.out.println("tokens.length is:"+tokens.length);
	if(tokens.length >= 10)
	{
		flag=true;
		System.out.println("The toekns flag is alpha "+flag);
	}
	else{
		
		System.out.println("The toekns flag is beta "+flag);
		return flag;
	}
	
	
	for(int i=0;i<tokens.length;i++){
		//check each value 
		//if the value is not number then return false
		try{
		token=Integer.parseInt(tokens[i]);
		}
		catch(Exception e){
			return false;
		}
		
		
		//min=java.lang.Math.min(min, token);
		//max=java.lang.Math.max(max, token);	
		if(token < 1 || token > 100 )
		{
			System.out.println("hey I am here Token"+token);
			flag=false;
			return false;
		}
		
		flag=true;
	}
	
	return flag;
}

}
