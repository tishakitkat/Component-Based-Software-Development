/*****************************
*@author tisha kanjilal
*
*@title  HW2 -SWE645 -Fall2017
*
*******************************/
package controller;
import java.util.ArrayList;
import org.postgresql.*;
import java.util.HashMap;
import java.util.Properties;
import java.util.StringTokenizer;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import oracle.jdbc.driver.OracleDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

public class StudentService {
	//int Id=0;
	//HashMap<Integer,String> hmap = new HashMap<Integer,String>();
	ArrayList<Student> alStudent=new ArrayList<Student>();
	
	 private static double myTokens[];
	 /**Calculate Mean**/
	 public double calculateMean(String Data)
	 {
	  String data=Data;
	  double sum=0.0,avg=0.0;
	  StringTokenizer stringTokenizer = new StringTokenizer(data, ",");
	  int tokenLength=stringTokenizer.countTokens(),i=0;
	  myTokens=new double[tokenLength];
	  while(stringTokenizer.hasMoreElements())
	  {
	   myTokens[i]=Double.parseDouble(stringTokenizer.nextElement().toString());
	   sum+=myTokens[i];
	   i++;
	  }
	  avg=sum/tokenLength;
	  return avg;
	 }
	 
	 /**Calculate Standard deviation**/
	 public double calculateStDev(String Data)
	 {
	  double mean=calculateMean(Data);
	  double variance=0.0,stDev=0.0;
	  double sum=0.0;
	  int len=myTokens.length;
	  for(int i=0;i<len;i++)
	  {
	   double val=myTokens[i]-mean;
	   double valsqr=val*val;
	   sum+=valsqr;
	   
	  }
	  variance=sum/len;
	  stDev=Math.sqrt(variance);
	    
	  return stDev;
	 }
	 
	 
	 /**Store survey data**/
	 
	 public void storeData(SurveyBean obj)
	 { 
		 
		 /*
		 String url = "jdbc:postgresql://localhost:5432/tisha";
		 Properties props = new Properties();
		 props.setProperty("user","tkanjila");
		 props.setProperty("password","ooboap");
		 props.setProperty("ssl","false");
		 //Connection conn = DriverManager.getConnection(url, props);
		 /**/
		// SurveyBean sb=new SurveyBean();
				 String chkbx="";
				 for(String s:obj.getCheck())
					{
						chkbx+=s;
						chkbx+=",";
					}
				 
				 Connection con = null;
				 Statement statement = null;
				 //ResultSet rs=null;
				 try{
					 Class.forName ("oracle.jdbc.driver.OracleDriver");
					 //Class.forName("org.postgresql.Driver");
					 //con = DriverManager.getConnection (url, props);
					 con = DriverManager.getConnection ("jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g", "tkanjila", "ooboap");
					 statement = con.createStatement();
					 String sql = "INSERT INTO surveyinfo "+"VALUES('"+obj.getFname()+"', '"+obj.getLname()+"','"+obj.getAddress()+"','"+obj.getCity()+"','"+obj.getState()+"','"+obj.getZip()+"','"+obj.getPhone()+"','"+obj.getEmail()+"','"+obj.getDate()+"','"+chkbx+"','"+obj.getRadio()+"','"+obj.getMenu()+"','"+obj.getComment()+"')";
					 
					 statement.executeUpdate (sql); 
					 System.out.println("Able to save data to database!!!!");
				 } catch (SQLException e) {
					   e.printStackTrace();
				  }catch (ClassNotFoundException e) {
				   e.printStackTrace();
				   }	 
				  
		 
	 }
	 
	 /**Retrieve survey data**/
	 
	 public ArrayList<Student> fetchData()
	 {
		 
		 /*
		 String url = "jdbc:postgresql://localhost:5432/tisha";
		 Properties props = new Properties();
		 props.setProperty("user","tkanjila");
		 props.setProperty("password","ooboap");
		 props.setProperty("ssl","false");
		 //Connection conn = DriverManager.getConnection(url, props);
		 /**/
		 Connection con = null;
		  Statement statement = null;
		  ResultSet rs=null;
		  
		  try {
		   Class.forName ("oracle.jdbc.driver.OracleDriver"); 
			//Class.forName("org.postgresql.Driver");
			//con = DriverManager.getConnection (url, props);
		   con = DriverManager.getConnection ("jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g", "tkanjila", "ooboap");
		   statement = con.createStatement();
		   String sql="SELECT * FROM surveyinfo";
		   rs=statement.executeQuery(sql);
		   while(rs.next()){
			   Student s = new Student();
			   s.setFname(rs.getString(1));
			   s.setLname(rs.getString(2));
			   s.setAddress(rs.getString(3));
			   s.setCity(rs.getString(4));
			   s.setState(rs.getString(5));
			   s.setZip(rs.getString(6));
			   s.setPhone(rs.getString(7));
			   s.setEmail(rs.getString(8));
			   s.setDate(rs.getString(9));
			   s.setChkbx(rs.getString(10));
			   s.setRadio(rs.getString(11));
			   s.setMenu(rs.getString(12));
			   s.setComment(rs.getString(13));
			   alStudent.add(s);
			  System.out.println("the firstname and lastname are: "+rs.getString(1)+" "+rs.getString(2)); 
		   }
		   
		   
		   //return alStudent;
		  } catch (SQLException e) {
			   e.printStackTrace();
		  }catch (ClassNotFoundException e) {
		   e.printStackTrace();
		   }
		return alStudent;
		 
	
		 
	 }

}
