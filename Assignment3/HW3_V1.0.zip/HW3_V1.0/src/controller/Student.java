/*****************************
*@author tisha kanjilal
*
*@title  HW2 -SWE645 -Fall2017
*
*******************************/
package controller;

import java.io.Serializable;
import java.util.Date;

public class Student implements Serializable {
	private String fname,lname,address,city,state,zip,phone,email,raffle,radio,menu,comment,date1;
	private String[] check;
	private String chkbx;
	private Date date,startdate;
	private static final long serialVersionUID = 1L;
	
	/**Setters and getters for all form fields from survey form**/
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	public String getDate1() {
		return date1;
	}

	public void setDate1(String date) {
		this.date1 = date;
	}
	
	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public String getRaffle() {
		return raffle;
	}

	public void setRaffle(String raffle) {
		this.raffle = raffle;
		System.out.print("Already set the raffle"+this.raffle);
	}

	public String[] getCheck() {
		return check;
	}

	public void setCheck(String[] check) {
		this.check = check;
	}

	public String getRadio() {
		return radio;
	}

	public void setRadio(String radio) {
		this.radio = radio;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getChkbx() {
		return chkbx;
	}

	public void setChkbx(String chkbx) {
		this.chkbx = chkbx;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}


	
		

}
