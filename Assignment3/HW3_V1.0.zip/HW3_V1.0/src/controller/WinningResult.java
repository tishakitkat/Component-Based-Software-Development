/*****************************
*@author tisha kanjilal
*
*@title  HW2 -SWE645 -Fall2017
*
*******************************/

package controller;

import java.util.ArrayList;

public class WinningResult {
	
	double  mean,stDev;
	ArrayList<Student> list=new ArrayList<Student>();
	 
	 /*** setters and getters for mean ***/
	 public void setmean(double mean)
	 {
	     this.mean=mean;
	 }
	 public double getmean()
	 {
	  return mean;
	 }
	 
	 /*** setters and getters for standard Deviation ***/
	 public void setstDev(double stDev)
	 {
	     this.stDev=stDev;
	 }
	 public double getstDev()
	 {
	  return stDev;
	 }
	 
	 /** getter and setter for List of students - survey info **/

	 public void setStudentList(ArrayList<Student> list)
	 {
	 	this.list=list;
	 }
	 public ArrayList<Student> getStudentList()
	 {
	  return this.list;
	 }

}
